---
name: aw-brainstorm
description: 'Explore product ideas, PRDs, and ambiguous feature requests through collaborative dialogue, then create or update durable feature intent when ready. Use when the user says "let''s brainstorm", "what should we build", or "help me think through X", presents a PRD, vague or ambitious feature request, or seems unsure about scope or direction -- even without explicitly asking to brainstorm. Use aw-prd when the requested output is a PRD.'
argument-hint: "[feature idea or problem to explore]"
---

# Brainstorm a Feature or Improvement

First action, if `.scripts/aw-gate.js` exists: `node .scripts/aw-gate.js track aw-brainstorm` (silent no-op otherwise).

Current year: 2026. Brainstorming defines what to build; `aw-plan` defines how. Output is not production code; an explicitly authorized disposable prototype may help resolve experiential uncertainty. Use repo-relative paths only.

PRDs and raw ideas usually contain implicit ambiguity and open questions. Treat PRD and idea intake as a discovery step that resolves enough product behavior to write durable intent. If the PRD is pasted or linked, use `aw-prd` first so the historical source artifact is preserved, then continue from the imported PRD path. Once product behavior is explicit enough, create or update the living feature spec in the same run. If the user wants a PRD as the output, route to `aw-prd`.

## Interaction

Ask one question at a time. Prefer concise single-select choices; use multi-select only for compatible sets. Use the platform blocking question tool; fall back to numbered chat only if unavailable/failing. Open-ended questions are fine when the answer is genuinely narrative and options would bias it.

## Principles

- Match ceremony to ambiguity and scope.
- Be a thinking partner: suggest alternatives, challenge assumptions, explore trade-offs.
- Resolve product/user behavior, scope, success criteria, and non-goals here.
- Prefer producing or updating the living spec for software/product work.
- Use `aw-prd` when the user wants a PRD artifact. Use lightweight ideation notes only when the concept is not ready for a PRD or living spec.
- Keep implementation details out unless the brainstorm is inherently technical.
- Prefer low carrying cost; avoid speculative future-proofing.

## Flow

1. If no feature description, ask what to explore.
2. Resume a recent matching `docs/brainstorms/*-requirements.md` only after user confirmation.
3. Classify domain:
   - software/product work -> continue
   - non-software exploration -> follow `references/universal-brainstorming.md`
   - quick factual/single-step request -> answer directly
4. Decide whether brainstorming is needed. If requirements are already clear and actionable, create/update the living spec directly or offer to proceed to `aw-plan`/`aw-work`; honor the user.
5. Assess depth:
   - brief alignment for simple low-risk work
   - standard requirements for normal feature/problem work
   - deep exploration for ambiguous, strategic, cross-cutting, or high-risk work
6. Gather context from user, repo, imported PRDs under `docs/product/prds/`, docs, learnings, and named resources. Use web/current research when outside facts may have changed. Use `aw-research` for focused evidence gathering or organizational context; it loads source-specific instructions only for selected sources.
7. Explore:
   - actors/users
   - problem and evidence
   - desired behavior and key flows
   - acceptance examples
   - scope boundaries/non-goals
   - success criteria
   - constraints/dependencies
   - risks and unresolved questions
8. Push on weak assumptions with targeted prompts. Use Experience Discovery below when consequential experiential uncertainty remains. Do not ask checklist questions just to fill a template.
9. Choose the output artifact:
   - living spec: default for software/product work that affects durable feature intent
   - PRD: route to `aw-prd` when the user asks to create or update a PRD
   - ideation doc: when the user wants to compare options or keep the concept exploratory without writing a PRD
   - no artifact: only for quick factual/single-step requests
10. Write or update the chosen artifact.
11. If `workflow.design.enabled` is true and `workflow.design.hooks.discovery.skill` is non-empty, invoke that design hook once with the brainstorm output artifact or final brainstorm context before handing off to the next workflow step. Include any experience interpretation, prototype agreement and scope, prototype reference, human feedback, and unresolved questions. Hook configuration does not authorize a prototype. Reuse existing agreement and feedback; reconcile new findings with intent before handoff without recursively rerunning hooks. Report unsupported hook behavior rather than bypassing the agreement boundary.

## Experience Discovery

Use this loop when the user requests experience exploration or when emotional
goals, visual references, or materially different plausible experiences leave
consequential uncertainty. A routine UI change with clear intent needs no probe.
The loop works even when design hooks are disabled or blank.

1. Make the interpretation inspectable: what should people understand, accomplish,
   and feel? Explain which observed qualities of references support those outcomes.
   State inaccessible references or other evidence gaps instead of inventing them.
2. Suggest a small disposable prototype and explain what it would clarify. Wait
   for agreement before creating it; silence is not agreement. An explicit request
   to create a prototype already authorizes its stated scope. Reuse agreement
   from the conversation rather than asking again. A broad build request alone
   does not authorize a separate exploratory prototype.
3. After agreement, use an available medium that can test the uncertainty. If it
   cannot, explain the limitation and agree on an alternative. Do not present an
   inadequate substitute as validation or expand the probe into production work.
4. Present the probe for a human reaction. Agreement to prototype is not approval
   of the resulting experience. Functional checks or silence cannot settle
   experiential fit; a mismatch stays open until addressed or explicitly deferred.
5. Carry useful discoveries into existing living-spec sections. Artifacts express
   partial evidence of human Theory; reading them does not give the agent Theory.
   Keep unresolved assumptions visible, including when exploration is declined.

If the user declines, create no prototype and do not repeat the same suggestion
without new information. Continue authorized work with the uncertainty explicit.
Prototypes need not become permanent artifacts: preserve useful learning without
requiring a lasting prototype link. Do not automatically delete existing user
files. No extra document or skill invocation is required for every change.

## Living Spec Output

For normal software/product work, create or update `docs/features/<feature>/spec.md` and update `docs/features/index.yml` without disrupting its existing schema.

If standards exist at `docs/standards/index.yml`, load applicable standards before writing. Spec-time annotations such as the `[e2e]` coverage marker are defined there, and this is one of the two places they can be applied.

Use the repo's existing spec format if present. Otherwise:

```markdown
---
title: <Feature Name>
status: active
created: YYYY-MM-DD
updated: YYYY-MM-DD
tags:
  - <tag>
related_decisions: []
---

# <Feature Name>

## Intent

## Users

## Current Behavior

## Key Flows

## Acceptance Criteria

## Boundaries and Non-Goals

## Open Questions / TODOs

## Decision Links
```

Rules for spec output:

- Preserve unresolved ambiguity as `Open Questions / TODOs`; do not hide product assumptions.
- Keep specs focused on durable behavior and intent, not implementation tasks or progress.
- Link imported PRDs, idea docs, brainstorm notes, and related decisions when they exist.
- When a source PRD under `docs/product/prds/` informs the spec, mark that PRD `status: promoted` in frontmatter and `docs/product/prds/index.yml`, and add `promoted: YYYY-MM-DD` plus `promoted_to: <spec path>`. Do not rewrite the PRD body.
- If `workflow.design.enabled` is true and `workflow.design.hooks.spec_review.skill` is non-empty, invoke that design hook with the spec path before human review or planning.
- Offer product/human review for the spec only when `human_review.spec.reviewers` is configured in `docs/workflow/config.yml`, the change is high-risk, or the user asked for review; otherwise finish without asking. If review is wanted, invoke `aw-request-human-review spec <spec path>`.

## Ideation Output

Create `docs/brainstorms/YYYY-MM-DD-###-slug-idea.md` (creating `docs/brainstorms/` if missing — installs do not create it) when the user wants exploratory notes but not a PRD or living spec. Use `aw-prd` for authored PRDs.

Use a right-sized structure:

```markdown
# <Title>

Created: YYYY-MM-DD
Status: draft|ready-for-spec

## Problem
## Users / Actors
## Goals
## Key Flows
## Acceptance Examples
## Scope Boundaries
## Success Criteria
## Constraints and Dependencies
## Open Questions
## Deferred for Later
## Spec Handoff
```

For tiny work, collapse sections but keep the core facts. For larger work, add IDs (`A1`, `F1`, `AE1`) where they improve traceability.

## Quality Gate

Before finishing, verify:

- product behavior is explicit enough that spec or planning will not invent it
- acceptance examples cover normal and edge flows
- scope boundaries are clear
- unresolved questions are labeled blocking vs deferred
- implementation details are absent unless needed to define product behavior
- paths are repo-relative

Final response: artifact path, major decisions, open questions, human-review status when a spec was written, and recommended next step. For a living spec, the usual next step is `aw-plan <spec path>` when implementation planning is needed. For ideation output, the usual next step is `aw-prd <artifact path>` when the user wants a PRD or `aw-create-spec <artifact path>` when ready to promote the idea into durable feature intent.
